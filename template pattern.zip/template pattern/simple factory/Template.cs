﻿namespace templatepattern
{
    public abstract class Game
    {
        public abstract void TicketBooking();
        public abstract void Toss();
        public abstract void GameStart();

        public void Initialize()
        {
            TicketBooking();
            Toss();
            GameStart();
        }
    }

    public class Cricket : Game
    {
        public override void GameStart()
        {
            Console.WriteLine("Cricket Game Started");
        }

        public override void TicketBooking()
        {
            Console.WriteLine("TicketBooking started");
        }

        public override void Toss()
        {
            Console.WriteLine("Cricket Toss is Started");
        }
    }

    public class Football : Game
    {
        public override void GameStart()
        {
            Console.WriteLine("Football Game Started");
        }

        public override void TicketBooking()
        {
            Console.WriteLine("TicketBooking started");
        }

        public override void Toss()
        {
            Console.WriteLine("Football Toss is Started");
        }
    }
}
