﻿// See https://aka.ms/new-console-template for more information



using templatepattern;

Game obj = new Cricket();
obj.Initialize();
Console.WriteLine();

Game obj1 = new Football();
obj1.Initialize();